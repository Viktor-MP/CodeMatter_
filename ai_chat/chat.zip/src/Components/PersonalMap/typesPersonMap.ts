
export interface DeveloperLevel  {
  level: string;
  knowledge: string[];
}


export interface PersonMapType {
  className: string;
}


export interface PersonType {
  className: string;
  buttonValue: string;
}
