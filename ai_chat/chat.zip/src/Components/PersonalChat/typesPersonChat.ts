
export interface formDataType {
    message: string,
    state: boolean
}



export interface startDataType {
    chat: boolean
}