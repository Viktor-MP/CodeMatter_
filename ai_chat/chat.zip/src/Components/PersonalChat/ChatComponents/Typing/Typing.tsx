
import "./Typing.scss"

const Typing = () => {

    return (
    <div className="chat-bubble">
        <div className="typing">
            <div className="dot"></div>
            <div className="dot"></div>
            <div className="dot"></div>
        </div>
    </div>

    )


}


export default Typing

// /home/vik/Documents/CodeMatter_/ai_chat/src/Components/PersonalChat/ChatComponents/Typing/Typing.tsx